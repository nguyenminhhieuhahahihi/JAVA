package accepted.player;

public enum SoundQuality {
    STANDARD,
    LOW,
    HIGH,
    SUPER
}
