package accepted.player;

public enum PlaybackState {
    NONE,
    PLAYING,
    PAUSED,
    STOPPED,
    ERROR
}
